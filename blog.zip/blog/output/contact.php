<?php $page= "contact";?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name=”description”>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<title>xyz</title>

<!-- normalize -->
<link rel="stylesheet" href="assets/css/normalize.min.css">
<!-- fav-icon -->    
<link rel="shortcut icon" href="assets/image/logo.png"> 
<!-- Bootstrap 4.4.1-->
<link rel="stylesheet" href="assets/bootstrap-4.5.2/css/bootstrap.min.css">
<!-- Font-Awesome -->
<link rel="stylesheet" href="assets/font-awesome-4.7.0/css/font-awesome.min.css">
<!-- google-fonts -->    
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Catamaran:wght@100;200;300;400;500;600;700;800;900&family=Merriweather:ital,wght@0,300;0,400;0,700;0,900;1,300;1,400;1,700;1,900&display=swap"
    rel="stylesheet">
<!-- Swiper Slider -->
<link rel="stylesheet" href="assets/swiper-master/package/css/swiper.css">
<!-- hover master -->
<link rel="stylesheet" href="assets/Hover-master/css/hover.css">
<!-- style.css -->
<link rel="stylesheet" href="assets/css/style.css">

</head>
<body>
    <main>
        <!-- header -->
        <header>
            <?php include("header.php"); ?>
        </header>

        
        <!-- section2 -->
        <section class="section2 mt-4">
            <div class="container pb-5">
                <div class="row">
                    <div class="col-12 mt-md-5 col-lg-8">
                        <div class="wrd-spe2">
                            <h2 class="h1">Say hello!</h2>
                            <p>entice, and convince consumers to take action. There is no <a href="#">magic formula</a> to write perfect ad copy; it is based on a number of factors, including ad placement, demographic, even the consumer’s mood when they see your ad. </p>

                            <p>Place your description here. Free photo from <a href="#">Unsplash</a></p>

                            <p>You could do this with a headline or slogan (such as VW’s “Drivers Wanted” campaign), color or layout (Target’s new colorful, simple ads are a testimony to this) or illustration (such as the Red Bull characters or Zoloft’s depressed ball and his ladybug friend).  All good advertising copy is comprised of the same basic elements. </p>
                            <h4>Simple & Beautiful</h4>
                            <p>How you write your advertising copy will be based on where you will place your ad. If it’s a billboard ad, you’ll need a super catchy headline and simple design due to the speed at which people will pass. Online ads are similar; consumers are so inundated with Internet advertising that your ad must be quick and catchy. </p>

                            <p>Email: maggy@easymeals.com (ullamcorper morbi tincidunt!)</p>
                        </div>  

                        <form name="frmContact" id="frmContact" method="post" action="#" enctype="multipart/form-data">
                            <div class="row mt-2">
                                <div class="form-group col-md-6 mt-4">
                                    <div class="border border-muted py-2 bg-light">
                                        <input type="text" placeholder="Full Name" name="txtName" id="txtName" class="form-control border-0 bg-light shadow-none">
                                    </div>
                                </div>
                                <div class="form-group col-md-6 mt-4">
                                    <div class="border border-muted py-2 bg-light">
                                        <input type="email" placeholder="Email Address" name="txtEmail" id="txtEmail" class="form-control bg-light border-0 shadow-none">
                                    </div>
                                </div>
                            </div>
                            <div class="form-group mt-4">
                                <div class="border border-muted py-2 bg-light">
                                    <input type="text" placeholder="Subject" name="txtSubject" id="txtSubject" class="form-control border-0 bg-light shadow-none">
                                </div>
                            </div>
                            <div class="form-group mt-4 pt-3">
                                <textarea name="txtMessage" id="txtMessage" class="form-control py-2 bg-light rounded-0 shadow-none" rows="5" placeholder="Message"></textarea>
                            </div>
                            <div class="form-group mt-4">
                                <a href="#" class="btn btn-dark text-white border-0 px-5 mt-3 py-3 rounded-0">SEND MESSAGE</a>
                            </div>
                        </form>
                    </div>


                    <div class="col-12 col-lg-4 pl-md-5 mt-5">
                        <h4 class="">Featured</h4>
                        <div class="progress mt-3" style="height: 1.9px;">
                            <div class="progress-bar bg-dark" style="width:20%;"></div>
                        </div>
                        <div class="mt-4">
                            <div class="row mt-4 pt-2">
                                <a class="col-4" href="#">
                                    <div class="parent rounded-lg mt-md-0 mt-2">
                                        <div class="child">
                                            <img class="w-100" src="assets/image/img1.jpg">
                                        </div>
                                    </div>
                                </a>
                                <div class="col-8 pl-0 align-self-center">
                                    <a class="text-hvr1" href="#">
                                        <h6 class="small mb-0">How To Find The Right Template For Your Specific Product</h6>
                                    </a>
                                    <p class="text-muted">
                                        <small><i class="fa fa-clock-o mr-2"></i> 3min read</small>
                                    </p>
                                </div>
                            </div>
                            <div class="row mt-1">
                                <a class="col-4" href="#">
                                    <div class="parent rounded-lg mt-md-0 mt-2">
                                        <img class="child w-100" src="assets/image/img2.jpg">
                                    </div>
                                </a>
                                <div class="col-8 pl-0 align-self-center">
                                    <a class="text-hvr1" href="#">
                                        <h6 class="small mb-0">How To Find The Right Template For Your Specific Product</h6>
                                    </a>
                                    <p class="text-muted">
                                        <small><i class="fa fa-clock-o mr-2"></i> 3min read</small>
                                    </p>
                                </div>
                            </div>
                            <div class="row mt-1">
                                <a class="col-4" href="#">
                                    <div class="parent rounded-lg mt-md-0 mt-2">
                                        <img class="child w-100" src="assets/image/img1.jpg">
                                    </div>
                                </a>
                                <div class="col-8 pl-0 align-self-center">
                                    <a class="text-hvr1" href="#">
                                        <h6 class="small mb-0">How To Find The Right Template For Your Specific Product</h6>
                                    </a>
                                    <p class="text-muted">
                                        <small><i class="fa fa-clock-o mr-2"></i> 3min read</small>
                                    </p>
                                </div>
                            </div>
                        </div>


                        <h4 class="mt-4">Tags</h4>
                        <div class="progress mt-3" style="height: 1.9px;">
                            <div class="progress-bar bg-dark" style="width:20%;"></div>
                        </div>
                        <div class="mt-4">
                            <a class="btn btn btns9 text-black1 border border-muted mt-2" href="#">
                            Adventure
                            </a>
                            <a class="btn btn btns9 text-black1 border border-muted mt-2" href="#">
                                Adventure
                            </a>
                            <a class="btn btn btns9 text-black1 border border-muted mt-2" href="#">
                                Adventure
                            </a>
                            <a class="btn btn btns9 text-black1 border border-muted mt-2" href="#">
                                Adventure
                            </a>
                            <a class="btn btn btns9 text-black1 border border-muted mt-2" href="#">
                                Adventure
                            </a>
                            <a class="btn btn btns9 text-black1 border border-muted mt-2" href="#">
                                Adventure
                            </a>
                            <a class="btn btn btns9 text-black1 border border-muted mt-2" href="#">
                                Adventure
                            </a>
                            <a class="btn btn btns9 text-black1 border border-muted mt-2" href="#">
                                Adventure
                            </a>
                            <a class="btn btn btns9 text-black1 border border-muted mt-2" href="#">
                                Adventure
                            </a>
                            <a class="btn btn btns9 text-black1 border border-muted mt-2" href="#">
                                Adventure
                            </a>
                            <a class="btn btn btns9 text-black1 border border-muted mt-2" href="#">
                                Adventure
                            </a>
                            <a class="btn btn btns9 text-black1 border border-muted mt-2" href="#">
                                Adventure
                            </a>
                            <a class="btn btn btns9 text-black1 border border-muted mt-2" href="#">
                                Adventure
                            </a>
                        </div>

                        <h4 class="mt-5">Newsletter</h4>
                        <div class="progress mt-3" style="height: 1.9px;">
                            <div class="progress-bar bg-dark" style="width:20%;"></div>
                        </div>
                        <div class="mt-4 text-dark">
                            <p>New posts straight to your inbox</p>
                            <form class="">
                                <input class="form-control p-4 bg-light" type="text" name="name" placeholder="Enter Your Email">
                                <button class="btn btn-warning border-0 btn-lg bg-gold w-100 mt-3 text-white" type="button"><small class="font-weight-bold">Subscribe</small></button>
                            </form>
                            <small>No spam ever. Read our <a class="text-gold" href="#"><u>Privacy Policy</u></a></small>
                        </div>
                    </div>
                </div>
            </div>
        </section>


        <!-- Contents 22 -->
        <section class="section2 pt-4">
            <div class="container">
                <div class="bg-light brd2 p-5">
                    <div class="row justify-content-center py-5">
                        <div class="col-12 col-lg-8 col-xl-6 text-center left-reveal">
                            <h2>We Offer You Partnership</h2>
                            <p class="mt-4">We love to partner with brands and products that we believe in. If you feel that your company shares values and would
                            benefit our readers, we would love to talk about working together.</p>
        
                            <a href="#" class="btn btn-warning px-5 py-3 mt-4 bg-gold border-0">Learn More</a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        

        <!-- footer -->
        <footer>
            <?php include("footer.php"); ?>
        </footer>
    </main>

<!-- bootstrap 4.4.1 -->
<script src="assets/bootstrap-4.5.2/js/jquery-3.4.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="assets/bootstrap-4.5.2/js/bootstrap.min.js"></script>
<!-- page-scrollreveal-3.3.2 -->
<script src="assets/page-scrollreveal-3.3.2/scrollreveal.min.js"></script>
<!-- Swiper Slider -->
<script src="assets/swiper-master/package/js/swiper.min.js"></script>

<!-- javascript.js --> 
<script src="assets/js/common.js"></script>          
<script src="assets/js/index.js"></script>

</body>
</html>