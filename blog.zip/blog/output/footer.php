  
<!--footer-->
<footer class="foot mt-5">
    <div class="container">
        <div class="row pb-3 left-reveal">
            <div class="col-12 col-md-6 col-lg-3 mt-5">
                <a class="navbar-brand text-dark" href="index.html">
                    <img class="w-100" src="assets/image/logo.png">
                </a>
                <p class="mt-4 text-muted"> Carefully crafted Webflow template for blog or magazine.</p>
            </div>

            <div class="col-12 col-md-6 col-lg-3 mt-5">
                <h5 class="mb-5">Navigation</h5>
                <a class="btn btn-outline-light text-dark hvr-icon-forward border border-left-0 border-right-0 border-bottom-0 mt-4 p-3 d-flex justify-content-between" href="#">
                    <span class="hvr-icon">Intro</span><small><small class="fa fa-chevron-right smll mt-2 align-self-center"></small></small>
                </a>
                <a class="btn btn-outline-light text-dark hvr-icon-forward border border-left-0 border-right-0 border-bottom-0 p-3 d-flex justify-content-between" href="#">
                    <span class="hvr-icon">Culture</span><small><small class="fa fa-chevron-right smll mt-2 align-self-center"></small></small>
                </a>
                <a class="btn btn-outline-light text-dark hvr-icon-forward border border-left-0 border-right-0 border-bottom-0 p-3 d-flex justify-content-between" href="#">
                    <span class="hvr-icon">Events</span><small><small class="fa fa-chevron-right smll mt-2 align-self-center"></small></small>
                </a>
                <a class="btn btn-outline-light text-dark hvr-icon-forward border border-left-0 border-right-0 border-bottom-0 p-3 d-flex justify-content-between" href="#">
                    <span class="hvr-icon">Lifestyle</span><small><small class="fa fa-chevron-right smll mt-2 align-self-center"></small></small>
                </a>
                <a class="btn btn-outline-light text-dark hvr-icon-forward border border-left-0 border-right-0 p-3 d-flex justify-content-between" href="#">
                    <span class="hvr-icon">Tech</span><small><small class="fa fa-chevron-right smll mt-2 align-self-center"></small></small>
                </a>
            </div>

            <div class="col-12 col-md-6 col-lg-3 mt-5">
                <h5 class="">Featured Posts</h5>
                <div class="row mt-4 pt-2">
                    <a class="col-4" href="#">
                        <div class="parent rounded-lg mt-md-0 mt-2">
                            <div class="child">
                                <img class="w-100" src="assets/image/h2-img-9-1.jpg">
                            </div>
                        </div>
                    </a>
                    <div class="col-8 pl-0 align-self-center">
                        <a class="text-dark" href="#">
                            <h6 class="small mb-0">How To Find The Right Template For Your Specific Product</h6>
                        </a>
                        <p class="text-muted">
                            <small><i class="fa fa-clock-o fa-lg mr-2"></i> 3min read</small>
                        </p>
                    </div>
                </div>
                <div class="row mt-1">
                    <a class="col-4" href="#">
                        <div class="parent rounded-lg mt-md-0 mt-2">
                            <img class="child w-100" src="assets/image/h2-img-9-1.jpg">
                        </div>
                    </a>
                    <div class="col-8 pl-0 align-self-center">
                        <a href="#" class="text-dark">
                            <h6 class="small mb-0">How To Find The Right Template For Your Specific Product</h6>
                        </a>
                        <p class="text-muted">
                            <small><i class="fa fa-clock-o fa-lg mr-2"></i> 3min read</small>
                        </p>
                    </div>
                </div>
                <div class="row mt-1">
                    <a class="col-4" href="#" class="text-dark">
                        <div class="parent rounded-lg mt-md-0 mt-2">
                            <img class="child w-100" src="assets/image/h2-img-9-1.jpg">
                        </div>
                    </a>
                    <div class="col-8 pl-0 align-self-center">
                        <a href="#" class="text-dark">
                            <h6 class="small mb-0">How To Find The Right Template For Your Specific Product</h6>
                        </a>
                        <p class="text-muted">
                            <small><i class="fa fa-clock-o fa-lg mr-2"></i> 3min read</small>
                        </p>
                    </div>
                </div>
            </div>

            <div class="col-12 col-md-6 col-lg-3 mt-5">
                <h5>Newsletters</h5>
                <div class="mt-4 text-dark">
                    <p>New posts straight to your inbox</p>
                    <form class="">
                        <input class="form-control p-4 bg-light" type="text" name="name" placeholder="Enter Your Email">
                        <button class="btn btn-warning btn-lg bg-gold w-100 mt-3 text-white" type="button"><small class="font-weight-bold">Subscribe</small></button>
                    </form>
                    <small>No spam ever. Read our <a href="#"><u>Privacy Policy</u></a></small>
                </div>
            </div>
        </div>
    </div>
</footer>

<div class="container foot">
    <hr>
    <div class="row left-reveal">
        <div class="col-12 col-md-7 mt-2 pt-1 text-lg-left text-muted">
            <p class="text-muted small">
                <small><i class="fa fa fa-lg mr-2">w</i> POWERED BY <a href="#" class="text-dark">WEBFLOW</a></small> |
                <small><i class="fa fa-heart-o fa-lg mr-2"></i> CREATED BY <a href="#" class="text-dark">ELASTIC THEMES</a></small> |
                <small><i class="fa fa-dollar fa-lg mr-2"></i> POWERED BY <a href="#" class="text-dark">BY TEMPLATE</a></small>
            </p>
        </div>
        <div class="col-12 col-md-5 mt-2 pt-1 text-center text-lg-right text-muted">
            <p class="text-muted small">
                <small><a href="#" class="text-dark">STYLE GUIDE</a></small>
                <small class="ml-3"><a href="#" class="text-dark">CHANGELOG</a></small>
                <small class="ml-3"><a href="#" class="text-dark">LICENSING</a></small>
            </p>
        </div>
    </div>
</div>
<!--scroll-top-->
<div>
    <a class="scroll-top" href="#"><i class="fa fa-angle-double-up text-white fa-lg px-2 rounded-lg py-2 bg-green"></i></a>
</div> 
   
