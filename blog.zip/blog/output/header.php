	
	<!--header-->
	<div class="container d-md-block d-none">
		<div class="row py-4">
			<div class="col-md-4 align-self-center">
				<a class="navbar-brand h1" href="index.php"><img class="w-75" src="assets/image/logo.png"></a>
			</div>
			<div class="col-md-5 text-center align-self-center">
				<div class="btn-group w-100">
					<input type="text" placeholder="Search" name="txtSearch" id="txtSearch"
						class="form-control border py-4 bg-light shadow-none">
					<button type="button" class="btn btn-warning bg-gold border-0 px-4"><i class="fa fa-search"></i></button>
				</div>
			</div>
			<div class="col-md-3 text-md-right text-center align-self-center">
				<a href="#" class="text-decoration-none text-dark"><i class="fa fa-bookmark mr-2"></i>Favourites</a>
			</div>
		</div>
	</div>
	
	<hr class="my-0">
	<nav class="navbar navbar-expand-md py-md-3 nav1">
		<div class="container">
			<a class="navbar-brand d-md-none d-block" href="index.php"><img class="w-75" src="assets/image/logo.png"></a>
			<button class="navbar-toggler navbar-light" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
				<span class="navbar-toggler-icon"></span>
			</button>
			<div class="collapse navbar-collapse" id="collapsibleNavbar">
				<ul class="navbar-nav">
					<li class="nav-item">
						<a class="nav-link <?php if($page=="home"){echo "active-menu";} ?>" href="index.php">HOME</a>
					</li>
					<li class="nav-item pl-md-3">
						<a class="nav-link <?php if($page=="about"){echo "active-menu";} ?>" href="about.php">ABOUT</a>
					</li>
					<li class="nav-item pl-md-3">
						<a class="nav-link <?php if($page=="contact"){echo "active-menu";} ?>" href="contact.php">CONTACT</a>
					</li>    
				</ul>
				<div class="mx-auto d-none ser">
					<div class="btn-group mt-md-0 mt-4">
						<input type="text" placeholder="Search" name="txtSearch" id="txtSearch"
							class="form-control border py-4 bg-light shadow-none">
						<button type="button" class="btn btn-warning bg-gold border-0 px-4"><i class="fa fa-search"></i></button>
					</div>
				</div>
			</div>  

			

			<div class="d-md-block d-none">
                <div class="d-flex justify-content-end align-self-end small">
                    <a href="#" class="text-decoration-none ml-4 text-hvr1">
                        <i class="fa fa-facebook fa-lg footer-icon"></i>
					</a>
                    <a href="#" class="text-decoration-none ml-4 text-hvr1">
                        <i class="fa fa-twitter fa-lg footer-icon"></i>
                    </a>
					<a href="#" class="text-decoration-none ml-4 text-hvr1">
                        <i class="fa fa-youtube fa-lg footer-icon"></i>
                    </a>
                </div>
            </div>
		</div>
	</nav>
	<hr class="mt-0">